const Pet = require('../models/petModel');
//Esta linha exporta a função para que ela possa ser usada em outras partes do aplicativo
exports.getAllPets = (req, res) => {
    // Esta linha chama uma função 
    Pet.getAllPets ((users) => {
        //Depois que os dados do usuário são recuperados, o método é usado para renderizar a exibição.
        res.render('index', { pets });
    });
};

exports.getPetById = (req, res) => {
    const petId = req.params.id;
    Pet.getPetById(petId, (pet) => {
        res.render('edit', { pet });
    });
};

///exibir usuário antes de deletar 
exports.getdeleteByPet = (req, res) => {
    const petId = req.params.id;
    Pet.getPetById(petId, (pet) => {
        res.render('dell', { pet });
    });
};

//ADICIONAR
exports.addPet = (req, res) => {
    const newPet = {
        nome: req.body.nome,
        raca: req.body.raca,
        porte: req.body.porte,
        cor: req.body.cor,
        especie: req.body.especie
    };
    Pet.addPet(newPet, () => {
        res.redirect('/');
    });
};

//ATUALIZAR
exports.updatePet = (req, res) => {
    const petId = req.params.id;
    const updatedPet = {
        nome: req.body.nome,
        raca: req.body.raca,
        porte: req.body.porte,
        cor: req.body.cor,
        especie: req.body.especie
    };
    Pet.updatePet(petId, updatedPet, () => {
        res.redirect('/');
    });
};

//DELETAR
exports.deletePet = (req, res) => {
    const petId = req.params.id;
    Pet.deletePet(petId, () => {
        res.redirect('/');
    });
};
