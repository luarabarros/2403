const express = require('express');
const bodyParser = require('body-parser');
const petController = require('./controllers/petController');
const app = express() //instância (objeto)

//Configura o EJS como mecnismo de visulização
app.set('view engine', 'ejs');

//Middlware para parsing do body
app.use(bodyParser.urlencoded({ extended: false }));

//Rotas
app.get('/', petController.getAllPets);
//adiciona
app.get('/add', (req, res) => res.render('add'));
app.post('/add', petController.addPet);
//edita
app.get('/edit/:id', petController.getPetById);
app.post('/edit/:id', petController.updatePet);
//deleta
app.get('/dell/:id', petController.getdeleteByPet);
app.post('/dell/:id', petController.deletePet);


//Iniciar o servidor 
app.listen(2000, () => {
    console.log('Servidor rodando na porta 2000');
})